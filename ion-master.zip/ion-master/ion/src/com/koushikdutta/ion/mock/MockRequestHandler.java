package com.koushikdutta.ion.mock;

/**
 * Created by koush on 3/6/15.
 */
public interface MockRequestHandler {
    public Object request(String uri);
}
