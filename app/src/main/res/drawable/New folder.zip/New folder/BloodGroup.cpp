#include"BloodGroup.h"
#include<string>

using namespace std;

//defining member variables and member functions

BloodGroup::BloodGroup(){};

BloodGroup::~BloodGroup(){};

BloodGroup::BloodGroup(string group)
{
	group=" ";

}

void BloodGroup::setGroup(string group)
{
	this->group=group;
}

string BloodGroup::getGroup()
{
	return group;
}
