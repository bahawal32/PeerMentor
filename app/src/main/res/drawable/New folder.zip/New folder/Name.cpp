#include"Name.h"
#include<string>

using namespace std;

//defining member functions and member variables

Name::Name() {};

Name::~Name() {};

Name::Name(string name)
{
	name=" ";
}

void Name::setName(string name)
{
	this->name=name;
}

string Name::getName()
{
	return name;
}
