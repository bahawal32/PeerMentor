#include"City.h"
#include<string>

using namespace std;

//defining member variables and member functions

City::City() {};

City::~City() {};

City::City(string city)
{
	city=" ";
}

void City::setCity(string city)
{	
	this->city=city;
}

string City::getCity()
{
	return city;
}
