#include"DataBase.h"
#include<string>

//defining member functions and menu

using namespace std;

DataBase::DataBase(){};

DataBase::~DataBase(){};

void DataBase::Data(string option)
{
        static int i=0;
        //Adding record of donor
        if(option=="Add New")
        {
            string name;
			int number;
            
			cout<<"\n\t\t\t Enter Your Name:"<<endl;
            cout<<" \t\t\t ";
            getchar();
            cin>>name;
            d[i].setName(name);
            
		    cout<<"\n\t\t\t Enter City:"<<endl;
            cout<<" \t\t\t ";
            getchar();
			cin>>name;
            d[i].setCity(name);
            
			cout<<"\n\t\t\t Enter Blood Group:"<<endl;
            cout<<" \t\t\t ";
            getchar();
			cin>>name;
            d[i].setGroup(name);
            
			cout<<"\n\t\t\t No.of Blood Donations:"<<endl;
            cout<<" \t\t\t ";
            cin>>number;
            d[i].setNumberOfDonations(number);

            cout<<"\n\t\t\t Last Date of Blood Donation:"<<endl;
            cout<<" \t\t\t ";
            getchar();
			cin>>name;
            d[i].setLastDateOfDonation(name);

            //cout<<"\n\t\t\t Enter Phone No.:"<<endl;
            //cout<<" \t\t\t ";
            //getchar();
			//cin>>name;
            //d[i].setPhoneNumber(name);
            
            cout<<"\n\t Your data has been successfully added to the our database."<<endl;
        
		    system("PAUSE");
            system("CLS");
        
		    i++;
        }
        
        //Viewing records
        if(option=="View")
        {
            int j;
            
			system("cls");
            
			for( j=0; j<i; j++)
            {  
				cout<<"\n\t\t\t\tDonar No: "<<j+1<<endl;
                cout<<"\t\t\tName: "<<d[j].getName()<<endl;
                cout<<"\t\t\tCity.: "<<d[j].getCity()<<endl;
                cout<<"\t\t\tBlood Group: "<<d[j].getGroup()<<endl;
                cout<<"\t\t\tNo. of Blood Donation: "<<d[j].getNumberOfDonations()<<endl;
                cout<<"\t\t\tLast Date of Blood Donation: "<<d[j].getLastDateOfDonation()<<endl;
                cout<<"\t\t\t:-:Contact Info:-:"<<endl;
               // cout<<"\t\t\tPhone No.: "<<d[j].getPhoneNumber()<<endl;
                cout<<"\n\n";
                
				system("PAUSE");
                system("CLS");
            }
            
            //Invalid entry
            if(j<1)
                cout<<"\aPlease Insert some data first.\n\n";
        }
        
        //Searching records
        if(option=="Search")
        {
            string s;
            
			system("cls");
            
			cout<<"\n\t\t\t\tEnter Your Name OR Blood Group OR City : "<<endl;
            cout<<"\t\t\t\t";
            cin>>s;
            for(int j=0; j<i+1; j++)
            {
                if(s==d[j].getGroup()||s==d[j].getName()||s==d[j].getCity())
                {
                	cout<<"\n\t\t\t\tDonar No: "<<j+1<<endl;
                	cout<<"\t\t\tName: "<<d[j].getName()<<endl;
                	cout<<"\t\t\tCity.: "<<d[j].getCity()<<endl;
                	cout<<"\t\t\tBlood Group: "<<d[j].getGroup()<<endl;
                	cout<<"\t\t\tNo. of Blood Donation: "<<d[j].getNumberOfDonations()<<endl;
                	cout<<"\t\t\tLast Date of Blood Donation: "<<d[j].getLastDateOfDonation()<<endl;
                	cout<<"\t\t\t:-:Contact Info:-:"<<endl;
                	//cout<<"\t\t\tPhone No.: "<<d[j].getPhoneNumber()<<endl;
                	cout<<"\n\n";
                	
					system("PAUSE");
                	system("CLS");
                }
            }

        }
    }

