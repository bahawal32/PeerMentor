#include"Donar.h"
#include<string>

using namespace std;

//defining member functions and variables

Donor::Donor() {};

Donor::Donor(int numberOfDonations, string lastDateofDonation)
{
	numberOfDonations=0;
	lastDateOfDonation=" ";
}

void Donor::setNumberOfDonations(int numberOfDonations)
{
	this->numberOfDonations=numberOfDonations;
}

int Donor::getNumberOfDonations()
{
	return numberOfDonations;
}

void Donor::setLastDateOfDonation(string lastDateOfDonation)
{
	this->lastDateOfDonation=lastDateOfDonation;
}

string Donor::getLastDateOfDonation()
{
	return lastDateOfDonation;
}

Donor::~Donor(){};
