
#include <iostream>
#include "DataBase.h"
#include<string>

using namespace std;
int main()
{
	
    DataBase db;

    while(1)
    {
        int choice;
        
		std::cout<<"\n\t\t===========================================";
        std::cout<<"\n\t\t  |    Blood Bank Management System   |"<<endl;
        std::cout<<"\t\t===========================================";
        std::cout<<"\n\t \t \t Select an option"<<endl;
        std::cout<<"\n\t\t\tTo Add New Data \t(1)";
		std::cout<<"\n\t\t\tTo View List Of Donar\t(2)";
		std::cout<<"\n\t\t\tTo Search Donar \t(3)";
		std::cout<<"\n\t\t\"\n\t\t\tTo Exit \t\t(4)"<<endl;
        std::cout<<"\t\t\t: ";
        
		std::cin>>choice;
        
		switch (choice)
        {

        case 1:
        {
            system("cls");
            db.Data("Add New");
        }
        break;

        case 2:
        {
            system("cls");
            db.Data("View");
        }
        break;
        case 3:
        {
            system("cls");
            db.Data("Search");
        }
        break;
     
        default :
        {
            std::cout<<"\a\aPlease Enter your choice Correctly:\a\a"<<endl;
        }
        break;
        }

    }
    return 0;
}
