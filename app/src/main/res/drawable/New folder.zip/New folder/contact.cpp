#include"contact.h"
#include<string>

using namespace std;

//defining member variables and functions

Contact::Contact() {};

Contact::~Contact() {};

Contact::Contact(string phoneNumber)
{
	phoneNumber=" ";
}
void Contact::setPhoneNumber(string phoneNumber)
{
	this->phoneNumber=phoneNumber;
}
string Contact::getPhoneNumber()
{
	return phoneNumber;
}
